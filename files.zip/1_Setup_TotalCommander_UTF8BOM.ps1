﻿#Requires -RunAsAdministrator
# ================================================================
# Total Commander Setup Tool
# ================================================================

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " Total Commander Setup Tool" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# ================================================================
# Step 1/3: Check Total Commander Path
# ================================================================
Write-Host "[Step 1/3] Checking Total Commander installation path..." -ForegroundColor Yellow
Write-Host ""

$tcFound = $false
$tcPath = ""

# Check common installation paths
$possiblePaths = @(
    "C:\Program Files\totalcmd\TOTALCMD64.EXE",
    "C:\Program Files\totalcmd\TOTALCMD.EXE",
    "C:\Program Files (x86)\totalcmd\TOTALCMD64.EXE",
    "C:\Program Files (x86)\totalcmd\TOTALCMD.EXE",
    "C:\totalcmd\TOTALCMD64.EXE",
    "C:\totalcmd\TOTALCMD.EXE"
)

foreach ($path in $possiblePaths) {
    if (Test-Path $path) {
        $tcPath = $path
        $tcFound = $true
        Write-Host "          Found: $tcPath" -ForegroundColor Green
        break
    }
}

if (-not $tcFound) {
    Write-Host "          [ERROR] Total Commander not found!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please enter the full path to Total Commander:"
    Write-Host "Example: D:\Tools\totalcmd\TOTALCMD64.EXE"
    Write-Host ""
    $tcPath = Read-Host "Enter path"
    
    if (-not (Test-Path $tcPath)) {
        Write-Host ""
        Write-Host "[ERROR] File not found!" -ForegroundColor Red
        Write-Host ""
        Read-Host "Press Enter to exit"
        exit 1
    }
    
    Write-Host ""
    Write-Host "          Confirmed: $tcPath" -ForegroundColor Green
}

Write-Host ""

# ================================================================
# Step 2/3: Backup Current Settings
# ================================================================
Write-Host "[Step 2/3] Backing up current settings..." -ForegroundColor Yellow
Write-Host ""

# Create backup folder
$backupDir = Join-Path $PSScriptRoot "Backups"
if (-not (Test-Path $backupDir)) {
    New-Item -Path $backupDir -ItemType Directory -Force | Out-Null
}

# Generate backup filename with timestamp
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$backupDirFile = Join-Path $backupDir "Directory_Shell_Backup_$timestamp.reg"
$backupDrvFile = Join-Path $backupDir "Drive_Shell_Backup_$timestamp.reg"

# Backup Directory shell
try {
    reg export "HKEY_CLASSES_ROOT\Directory\shell" $backupDirFile /y | Out-Null
    Write-Host "          [SUCCESS] Folder settings backed up" -ForegroundColor Green
} catch {
    Write-Host "          [FAILED] Backup failed" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

# Backup Drive shell
try {
    reg export "HKEY_CLASSES_ROOT\Drive\shell" $backupDrvFile /y | Out-Null
    Write-Host "          [SUCCESS] Drive settings backed up" -ForegroundColor Green
} catch {
    Write-Host "          [FAILED] Backup failed" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host ""
Write-Host "          Backup location: $backupDir" -ForegroundColor Gray
Write-Host ""

# ================================================================
# Step 3/3: Apply Total Commander Settings
# ================================================================
Write-Host "[Step 3/3] Applying Total Commander settings..." -ForegroundColor Yellow
Write-Host ""

# Convert path to Registry format (double backslashes)
$tcPathReg = $tcPath -replace '\\', '\\'

# Create temporary Registry file
$tempReg = Join-Path $env:TEMP "TC_Setup.reg"

# Create Registry content
$regContent = @"
Windows Registry Editor Version 5.00

; ================================================================
; Set default folder open with Total Commander
; ================================================================

[HKEY_CLASSES_ROOT\Directory\shell]
@="none"

[HKEY_CLASSES_ROOT\Directory\shell\open]
@="Open with Total Commander(&O)"
"Icon"="$tcPathReg,0"

[HKEY_CLASSES_ROOT\Directory\shell\open\command]
@="\"$tcPathReg\" /O /T /S \"%1\""

; ================================================================
; Set default drive open with Total Commander
; ================================================================

[HKEY_CLASSES_ROOT\Drive\shell]
@="none"

[HKEY_CLASSES_ROOT\Drive\shell\open]
@="Open with Total Commander(&O)"
"Icon"="$tcPathReg,0"

[HKEY_CLASSES_ROOT\Drive\shell\open\command]
@="\"$tcPathReg\" /O /T /S \"%1\""
"@

# Write file (using Unicode encoding)
[System.IO.File]::WriteAllText($tempReg, $regContent, [System.Text.Encoding]::Unicode)

# Import Registry
try {
    $result = Start-Process "reg" -ArgumentList "import `"$tempReg`"" -Wait -PassThru -NoNewWindow
    if ($result.ExitCode -eq 0) {
        Write-Host "          [SUCCESS] Total Commander set as default" -ForegroundColor Green
    } else {
        Write-Host "          [FAILED] Setup failed" -ForegroundColor Red
        Remove-Item $tempReg -Force -ErrorAction SilentlyContinue
        Read-Host "Press Enter to exit"
        exit 1
    }
} catch {
    Write-Host "          [FAILED] Setup failed: $_" -ForegroundColor Red
    Remove-Item $tempReg -Force -ErrorAction SilentlyContinue
    Read-Host "Press Enter to exit"
    exit 1
}

# Cleanup temporary file
Remove-Item $tempReg -Force -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " Setup Complete!" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "OK Total Commander path: $tcPath" -ForegroundColor Green
Write-Host "OK Backup location: $backupDir" -ForegroundColor Green
Write-Host ""
Write-Host "IMPORTANT:" -ForegroundColor Yellow
Write-Host "1. Please log out and log back in, or restart"
Write-Host "2. Settings will take effect after re-login"
Write-Host ""
Write-Host "Test items:" -ForegroundColor Cyan
Write-Host "- Double-click a folder on desktop"
Write-Host "- Double-click C: drive in This PC"
Write-Host "- Win+R, type C:\, press Enter"
Write-Host "- VS Code right-click -> Reveal in File Explorer"
Write-Host ""
Write-Host "To restore, run:" -ForegroundColor Yellow
Write-Host "  2_Restore_Explorer.ps1"
Write-Host ""
Read-Host "Press Enter to exit"
